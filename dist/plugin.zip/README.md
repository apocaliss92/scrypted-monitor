# Scrypted plugins monitor

https://github.com/apocaliss92/scrypted-monitor - For requests and bugs

Scrypted plugin that can run the following actions on a scheduled base:
- Run diagnostics
- Update plugins
- Restart plugins

The result of the runs can be sent on a notifier

TODO
Add test button